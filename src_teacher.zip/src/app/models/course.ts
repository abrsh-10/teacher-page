export class Course {
  id!: string;
  courseId!: string;
  courseName!: string;
  courseDescription!: string;
  teacherEmail!: string;
  courseImage!: string;
}
