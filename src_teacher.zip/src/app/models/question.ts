export class Question {
  question!: string;
  questionType!: string;
  options?: string[];
}
