export enum Role {
    Student = 'Student',Teacher = 'Teacher',Admin = 'Admin'
}
